/* Make everything dimmed */
.block_page_module span.dimmed_text * {
    color: inherit !important;
}