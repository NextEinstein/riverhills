<?PHP  //$Id: version.php,v 1.15 2007/08/13 02:57:05 toyomoyo Exp $
// This file defines the current version of the
// blocks code that is being used.  This can be
// compared against the values stored in the
// database (blocks_version) to determine whether upgrades should
// be performed (see db/backup_*.php)

$blocks_version = 2007081300;   // The current version is a date (YYYYMMDDXX)
?>