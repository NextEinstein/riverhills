<?PHP

// version $Id: languages.php,v 1.7 2007/10/09 21:43:28 iarenaza Exp $

// List of CAS langages.

// You can add langages in /CAS/langage.

// Please send them to http://esup-phpcas.sourceforge.net

$CASLANGUAGES = array (

"english" => "English",

"french" => "French");

?>
