README $Id: README.txt,v 1.2 2003/04/29 21:09:26 stronk7 Exp $
----------

This directory contains my try to create a backup/recover 
admin option to moodle. I don't know when and how it'll be 
finished, but I'going to try it, sure.

Some day, if this is fully functional, it could be integrated 
into the main Moodle distribution (ask uncle Martin).   :-)

Code here may not be tested - so there are no guarantees as
to the quality of the code in here, even if part of a stable
Moodle release.

Please, for any comment about this option, do it in Moodle
Developer Forum at:
   
   http://moodle.org/mod/forum/view.php?id=55
   (searching an "backup" topic) 

or you can put tour comments in Moodel Bugs at: 

   http://moodle.org/bugs/bug.php?op=show&bugid=84.

All comments will be welcome. TIA.

To see the general status of the utility, take a look to
"STATUS.txt" in this directory.

And this is all, I start with it NOW. 

Eloy (stronk7)
29-04-2003
