<?php // %Id%

    require('../config.php');

    redirect($CFG->wwwroot.'/calendar/view.php');

?>
